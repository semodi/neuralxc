patch -p1 -s < siesta_nxc.patch
curl https://raw.githubusercontent.com/ylikx/forpy/master/forpy_mod.F90 > forpy_mod.F90
